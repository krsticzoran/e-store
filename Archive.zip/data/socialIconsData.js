export const socialIconsData = [
  {
    title: "facebook",
    link: "https://www.facebook.com/",
    src: "fa-facebook-f",
  },
  {
    title: "youtube",
    link: "https://www.youtube.com/",
    src: "fa-youtube",
  },
  {
    title: "instagram",
    link: "https://www.instagram.com/",
    src: "fa-instagram",
  },
  {
    title: "linkedin",
    link: "https://www.linkedin.com/",
    src: "fa-linkedin-in",
  },
];
