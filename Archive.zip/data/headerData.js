export const pages = ["", "shop", "about", "contact"];

export const companyInfo = [
  { href: "/#", text: "5 Rue Dalou, 75015 Paris" },
  { href: "tel:+33 156 78 89 56", text: "+33 156 78 89 56" },
  { href: "mailto:example@company.com", text: "example@company.com" },
];
