export const companyData = {
  title: "company",
  links: ["about us", "our history", "shop", "my account", "contact us"],
};

export const discoverData = {
  title: "discover",
  links: [
    "Black Tea Varieties",
    "Premium Green Tea",
    "Oolong Tea Blends",
    "Flavored Tea Collection",
    "Exclusive Sales",
  ],
};
