export default function Shop() {
  return <p>shop</p>;
}
